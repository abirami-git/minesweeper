#include <stdio.h>
#include <stdlib.h>
#include <time.h>
int main()
{
 int r,a,b,count=0;
 srand((unsigned)time(NULL));
 int mine_pos[20]={0},i=0;
while(count!=1)
{

 r=rand();
 r=(r%16);
 mine_pos[i++]=r;
count++;

}
char user_display_board[4][4]={"abcd","efgh","ijkl","mnop"};
char backend_board[4][4]={"abcd","efgh","ijkl","mnop"};

 for(int i=0;i<6;i++)
 {
     switch(mine_pos[i]+1)
     {
         case 1:
         backend_board[0][0]='*';
         break;
          case 2:
         backend_board[0][1]='*';
         break;
          case 3:
         backend_board[0][2]='*';
         break;
          case 4:
         backend_board[0][3]='*';
         break;
         case 5:
         backend_board[1][0]='*';
         break;
          case 6:
         backend_board[1][1]='*';
         break;
          case 7:
         backend_board[1][2]='*';
         break;
          case 8:
         backend_board[1][3]='*';
         break;
          case 9:
         backend_board[2][0]='*';
         break;
          case 10:
         backend_board[2][1]='*';
         break;
          case 11:
         backend_board[2][2]='*';
         break;
          case 12:
         backend_board[2][3]='*';
         break;
         case 13:
         backend_board[3][0]='*';
         break;
         case 14:
         backend_board[3][1]='*';
         break;
          case 15:
         backend_board[3][2]='*';
         break;
          case 16:
         backend_board[3][3]='*';
         break;
     }
 }

 for(int i=0;i<4;i++)
 {
     for(int j=0;j<4;j++)
     {
         if(i+1<4 && j+1<4 && i-1>=0 && j-1>=0)
        for(int k=i-1;k<=i+1;k++)
        {
            for(int l=j-1;l<=j+1;l++)
            {
              if(backend_board[k][l]=='*')
              {
                  count++;
              }
            // printf("%c ",user_display_board[k][l]);
            }


        }
        if(count==1)
        {
            backend_board[i][j]='1';
        }

     }


 }
 for(int i=0;i<4;i++)
 {
     for(int j=0;j<4;j++)
     {
         printf("%c ",backend_board[i][j]);
     }
     printf("\n");
 }
 printf("\n-----------------------\n");
 int var=12,flag=1;
 while(var--)
 {
     char position;
     int row_value,col_value;
     scanf("%c\n",&position);
     switch(position)
     {
         case 'a':
         row_value=0,col_value=0;
         break;
         case 'b':
         row_value=0,col_value=1;
         break;
         case 'c':
         row_value=0,col_value=2;
         break;
         case 'd':
         row_value=0,col_value=3;
         break;
         case 'e':
         row_value=1,col_value=0;
         break;
         case 'f':
         row_value=1,col_value=1;
         break;
         case 'g':
         row_value=1,col_value=2;
         break;
         case 'h':
         row_value=1,col_value=3;
         break;
         case 'i':
         row_value=2,col_value=0;
         break;
         case 'j':
         row_value=2,col_value=1;
         break;
         case 'k':
         row_value=2,col_value=2;
         break;
         case 'l':
         row_value=2,col_value=3;
         break;
         case 'm':
         row_value=3,col_value=0;
         break;
         case 'n':
         row_value=3,col_value=1;
         break;
         case 'o':
         row_value=3,col_value=2;
         break;
         case 'p':
         row_value=3,col_value=3;
         break;

     }
     //printf("%d %d\n",row_value,col_value);
    if(backend_board[row_value][col_value]=='*')
    {
        printf("SORRY YOU'VE LOST ..!!!\n");
        flag=1;
        return 0;
    }
    else
    {


         int count=0;
         if(col_value+1<4)
         for(int k=row_value;k<=row_value+1;k++)
         {
             for(int l=col_value;l<=col_value+1;l++)
             {
                 if(backend_board[k][l]=='*')
                 {
                     count++;

                 }
             }
         }
         if(count==0 && row_value+1<4 && col_value+1<4)
         {
          for(int k=row_value;k<=row_value+1;k++)
            {
                for(int l=col_value;l<=col_value+1;l++)
                {
                  user_display_board[k][l]='1';
                }
            }
         }


    }




 for(int i=0;i<4;i++)
 {
     for(int j=0;j<4;j++)
     {
      printf("%c ",user_display_board[i][j]);
     }
     printf("\n");
 }
 printf("\n\n");

}
if(flag==1)
printf("YOU HAVE WON");

 return(0);
}
